// Carrega a imagem e a exibe no canvas
const canvasOriginal = document.getElementById('canvasOriginal');
const ctxOriginal = canvasOriginal.getContext('2d');
const imagem = new Image();
imagem.src = 'imagem.png';
imagem.onload = function() {
  ctxOriginal.drawImage(imagem, 0, 0, canvasOriginal.width, canvasOriginal.height);
}

// Canvas para a exibição da imagem modificada
const canvasModificado = document.getElementById('canvasModificado');
const ctxModificado = canvasModificado.getContext('2d');

// Função para espelhar horizontalmente a imagem
function espelharHorizontalmente() {
  // Copia a imagem original para o canvas modificado
  canvasModificado.width = canvasOriginal.width;
  canvasModificado.height = canvasOriginal.height;
  ctxModificado.drawImage(imagem, 0, 0, canvasOriginal.width, canvasOriginal.height, 0, 0, canvasOriginal.width, canvasOriginal.height);

  // Espelha a imagem no canvas modificado
  const imageData = ctxModificado.getImageData(0, 0, canvasOriginal.width, canvasOriginal.height);
  const pixels = imageData.data;
  for (let i = 0; i < pixels.length; i += 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    const a = pixels[i + 3];
    const x = (i / 4) % canvasOriginal.width;
    const y = Math.floor(i / 4 / canvasOriginal.width);
    const newX = canvasOriginal.width - x - 1;
    const newIndex = (y * canvasOriginal.width + newX) * 4;
    pixels[newIndex] = r;
    pixels[newIndex + 1] = g;
    pixels[newIndex + 2] = b;
    pixels[newIndex + 3] = a;
  }
  ctxModificado.putImageData(imageData, 0, 0);
}

// Variável para indicar se a imagem foi espelhada horizontalmente
let espelhadoHorizontalmente = false;

// Adiciona o evento de clique no botão "Espelhar Horizontalmente"
const btnEspelharHorizontalmente = document.getElementById('btnEspelharHorizontalmente');
btnEspelharHorizontalmente.addEventListener('click', function() {
    if (!espelhadoHorizontalmente) {
        espelharHorizontalmente();
        espelhadoHorizontalmente = true;
      } else {
        drawImage();
        espelhadoHorizontalmente = false;
      }
    });
// cria o objeto de imagem
var imagem = new Image();

// define o caminho da imagem
imagem.src = "imagem.png";

// espera a imagem ser carregada
imagem.onload = function () {
  // cria o canvas original e modificado
  var canvasOriginal = document.getElementById("canvasOriginal");
  var canvasModificado = document.getElementById("canvasModificado");

  // define as dimensões dos canvas
  canvasOriginal.width = imagem.width;
  canvasOriginal.height = imagem.height;
  canvasModificado.width = imagem.width;
  canvasModificado.height = imagem.height;

  // desenha a imagem original no canvas original
  var ctxOriginal = canvasOriginal.getContext("2d");
  ctxOriginal.drawImage(imagem, 0, 0);

  // define o contexto 2D para o canvas modificado
  var ctxModificado = canvasModificado.getContext("2d");

  // define as variáveis de controle de estado
  var espelharHorizontal = false;
  var espelharVertical = false;
  var girar90graus = 0;
  var redimensionar = 1;

  // função para atualizar o canvas modificado
  function atualizarCanvasModificado() {
    // limpa o canvas modificado
    ctxModificado.clearRect(0, 0, canvasModificado.width, canvasModificado.height);

    // desenha a imagem original no canvas modificado
    ctxModificado.save();

    // aplica as transformações definidas
    if (espelharHorizontal) {
      ctxModificado.translate(canvasModificado.width, 0);
      ctxModificado.scale(-1, 1);
    }
    if (espelharVertical) {
      ctxModificado.translate(0, canvasModificado.height);
      ctxModificado.scale(1, -1);
    }
    if (girar90graus == 1) {
      ctxModificado.translate(canvasModificado.width, 0);
      ctxModificado.rotate(Math.PI / 2);
    } else if (girar90graus == 2) {
      ctxModificado.translate(canvasModificado.width, canvasModificado.height);
      ctxModificado.rotate(Math.PI);
    } else if (girar90graus == 3) {
      ctxModificado.translate(0, canvasModificado.height);
      ctxModificado.rotate(-Math.PI / 2);
    }

    ctxModificado.drawImage(imagem, 0, 0, imagem.width * redimensionar, imagem.height * redimensionar);
    ctxModificado.restore();
  }

  // evento de clique do botão de espelhamento horizontal
  document.getElementById("btnEspelharHorizontal").addEventListener("click", function () {
    espelharHorizontal = !espelharHorizontal;
    atualizarCanvasModificado();
  });

  // evento de clique do botão de espelhamento vertical
  document.getElementById("btnEspelharVertical").addEventListener("click", function () {
    espelharVertical = !espelharVertical;
    atualizarCanvasModificado();
  });

  // evento de clique do botão de rotação
  document.getElementById("btnRotacionar").addEventListener("click", function () {
    girar90graus = (girar90graus + 1) % 4;
    atualizarCanvasModificado();
  });

  // evento de clique do botão de redimensionamento
  document.getElementById("btnRedimensionar").addEventListener("click", function () {
    redimensionar *= 0.5;
    atualizarCanvasModificado();
  });
}

